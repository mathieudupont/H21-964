<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php bloginfo('name'); ?></title>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,900&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php bloginfo('template_url') ?>/assets/styles.css">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <header class="header section">
        <a href="<?php bloginfo('url'); ?>" class="header__brand"><?php bloginfo('name'); ?></a>

        <?php wp_nav_menu(array(
            'theme_location' => 'menu_principal')
        ); ?>
    </header>