<?php get_header(); ?>

<?php if (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); ?>
        <section class="hero">
            <div class="wrap">
                <div class="hero__medias">
                    <div class="hero__image">
                        <?php the_post_thumbnail(); ?>
                    </div>
                </div>
            </div>
        </section>

        <section class="grid section wrap">
            <h1 class="grid__title">
                <?php the_title(); ?>

                <?php if (get_field('cw4_acteur_oscar')): ?>
                    <small>🥇</small>
                <?php endif; ?>
            </h1>
            <div class="grid__content o-typography">
                <?php the_content(); ?>
            </div>
            <div class="grid__sidebar o-typography">
            <?php if (get_field('cw4_acteur_naissance')): ?>
                    <h3>Date de naissance</h3>
                    <p><?php the_field('cw4_acteur_naissance') ?></p>    
                <?php endif; ?>

                <?php if (get_field('cw4_acteur_nationalite')): ?>
                    <h3>Nationalité</h3>
                    <p><?php the_field('cw4_acteur_nationalite') ?></p>
                <?php endif; ?>

                <?php if( have_rows('cw4_acteur_sociaux') ): ?>
                    <h3>Réseaux Sociaux</h3>
                    <ul class="social">
                        <?php while( have_rows('cw4_acteur_sociaux') ): the_row(); ?>
                            <?php if ( get_sub_field('type') === 'LinkedIn' ) : ?>
                                <li><a href="<?php the_sub_field('url'); ?>" target="_blank">
                                    <i class="fab fa-linkedin-in"></i>
                                </a></li>
                            <?php elseif ( get_sub_field('type') === 'Instagram') : ?>
                                <li><a href="<?php the_sub_field('url'); ?>" target="_blank">
                                    <i class="fab fa-instagram"></i>
                                </a></li>
                            <?php elseif ( get_sub_field('type') === 'Facebook') : ?>
                                <li><a href="<?php the_sub_field('url'); ?>" target="_blank">
                                    <i class="fab fa-facebook-f"></i>
                                </a></li>
                            <?php elseif ( get_sub_field('type') === 'Twitter') : ?>
                                <li><a href="<?php the_sub_field('url'); ?>" target="_blank">
                                    <i class="fab fa-twitter"></i>
                                </a></li>
                            <?php endif; ?>
                        <?php endwhile; ?>
                    </ul>
                <?php endif; ?>

                <?php if (get_field('cw4_acteur_imdb')): ?>
                    <h3>Page IMDB</h3>
                    <a href="<?php the_field('cw4_acteur_imdb') ?>" target="_blank" rel="noopener">
                        En savoir plus
                    </a>
                <?php endif; ?>
            </div>
        </section>

        <?php $posts = get_field('cw4_acteur_films'); ?>
        <?php if ($posts): ?>
            <section class="section wrap o-typography">
                <h2>Films à son actif</h2>
                <div class="cards">
                    <!-- film -->
                    <article class="card">
                        <a href="#">
                            <div class="card__media">
                                <img src="<?php bloginfo('template_url'); ?>/assets/affiche.jpg" alt="Photo de l'acteur">
                            </div>
                            <div class="card__content o-typography">
                                <h2>
                                    Covid: La naissance (2019)
                                </h2>
                                <div>
                                    <h3>Réalisateur</h3>
                                    <p>Jean-François Imbert</p>
                                </div>
                            </div>
                        </a>
                    </article>

                    <!-- film -->
                    <article class="card">
                        <a href="#">
                            <div class="card__media">
                                <img src="<?php bloginfo('template_url'); ?>/assets/affiche.jpg" alt="Photo de l'acteur">
                            </div>
                            <div class="card__content o-typography">
                                <h2>
                                    Covid: Le retour (2020)
                                </h2>
                                <div>
                                    <h3>Réalisateur</h3>
                                    <p>Jean-François Imbert</p>
                                </div>
                            </div>
                        </a>
                    </article>

                </div>
            </section>
        <?php endif; ?>
    <?php endwhile; ?>
<?php endif; ?>

<?php get_footer(); ?>