<?php

add_theme_support('post-thumbnails');
set_post_thumbnail_size(800, 480);
add_image_size('vignette', 220, 100, true);

function new_excerpt_length($length) {
    return 10; // Nombre de mots limite
}
add_filter('excerpt_length', 'new_excerpt_length');

// Register Custom Post Type
function cw4_movies() {

	$labels = array(
		'name'                  => _x( 'Films', 'Post Type General Name', 'cw4_movies' ),
		'singular_name'         => _x( 'Film', 'Post Type Singular Name', 'cw4_movies' ),
		'menu_name'             => __( 'Films', 'cw4_movies' ),
		'name_admin_bar'        => __( 'Post Type', 'cw4_movies' ),
		'archives'              => __( 'Item Archives', 'cw4_movies' ),
		'attributes'            => __( 'Item Attributes', 'cw4_movies' ),
		'parent_item_colon'     => __( 'Parent Item:', 'cw4_movies' ),
		'all_items'             => __( 'Tous les films', 'cw4_movies' ),
		'add_new_item'          => __( 'Ajouter un film', 'cw4_movies' ),
		'add_new'               => __( 'Ajouter un film', 'cw4_movies' ),
		'new_item'              => __( 'Nouveau film', 'cw4_movies' ),
		'edit_item'             => __( 'Éditer le film', 'cw4_movies' ),
		'update_item'           => __( 'MAJ le film', 'cw4_movies' ),
		'view_item'             => __( 'View Item', 'cw4_movies' ),
		'view_items'            => __( 'View Items', 'cw4_movies' ),
		'search_items'          => __( 'Search Item', 'cw4_movies' ),
		'not_found'             => __( 'Not found', 'cw4_movies' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'cw4_movies' ),
		'featured_image'        => __( 'Featured Image', 'cw4_movies' ),
		'set_featured_image'    => __( 'Set featured image', 'cw4_movies' ),
		'remove_featured_image' => __( 'Remove featured image', 'cw4_movies' ),
		'use_featured_image'    => __( 'Use as featured image', 'cw4_movies' ),
		'insert_into_item'      => __( 'Insert into item', 'cw4_movies' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'cw4_movies' ),
		'items_list'            => __( 'Items list', 'cw4_movies' ),
		'items_list_navigation' => __( 'Items list navigation', 'cw4_movies' ),
		'filter_items_list'     => __( 'Filter items list', 'cw4_movies' ),
	);
	$args = array(
		'label'                 => __( 'Film', 'cw4_movies' ),
		'description'           => __( 'Films', 'cw4_movies' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-editor-video',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'movies', $args );

}
add_action( 'init', 'cw4_movies', 0 );


// enlever les attributs width / height des balises images insérées
// avec the_post_thumbnail
function cw4_img_no_attributes( $html, $post_id, $post_image_id ) {
    $html = preg_replace( '/(width|height)=\"\d*\"\s/', "", $html );
    return $html;
}
add_filter('post_thumbnail_html', 'cw4_img_no_attributes', 10, 3);