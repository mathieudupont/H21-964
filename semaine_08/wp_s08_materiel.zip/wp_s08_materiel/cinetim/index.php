<?php get_header(); ?>

<section class="section">
    <h1>Films à l'affiche</h1>
    <p>Suivez les instructions suivantes afin de faire apparaître les films en fonction des critères demandés. Bon cinéma!🍿🥤</p>
    
    <!-- bloc query_posts 1 -->
    <h2 class="wrap-short">Les 8 films les plus anciens <span>du plus vieux au plus récent</span></h2>
    <div class="movies">
        <!-- film -->
        <article class="movie">
            <div class="movie__media">
                <img src="assets/affiche.jpg" alt="Affiche du film Joker">
            </div>
            <div class="movie__content">
                <h2>
                    Joker
                    <span>(2019)</span>
                </h2>
                Le résumé lorem ipsum
            </div>
        </article>
        <!-- fin film -->
    </div>
    <!-- fin bloc query_posts 1 -->

    <!-- bloc query_posts 2 -->
    <h2>4 films d'action <span>au hasard à chaque fois</span></h2>
    <div class="movies">
        <!-- film -->
        <article class="movie">
            <div class="movie__media">
                <img src="assets/affiche.jpg" alt="Affiche du film Joker">
            </div>
            <div class="movie__content">
                <h2>
                    Joker
                    <span>(2019)</span>
                </h2>
                Le résumé lorem ipsum
            </div>
        </article>
        <!-- fin film -->
    </div>
    <!-- fin bloc query_posts 2 -->

    <!-- bloc query_posts 3 -->
    <h2>tous les films de science-fiction <span>en ordre alphabétique</span></h2>
    <div class="movies">
        <!-- film -->
        <article class="movie">
            <div class="movie__media">
                <img src="assets/affiche.jpg" alt="Affiche du film Joker">
            </div>
            <div class="movie__content">
                <h2>
                    Joker
                    <span>(2019)</span>
                </h2>
                Le résumé lorem ipsum
            </div>
        </article>
        <!-- fin film -->
    </div>
    <!-- fin bloc query_posts 3 -->

    <!-- bloc query_posts 4 -->
    <h2>tous les drames <span>du plus anciens au plus récent</span></h2>
    <div class="movies">
        <!-- film -->
        <article class="movie">
            <div class="movie__media">
                <img src="assets/affiche.jpg" alt="Affiche du film Joker">
            </div>
            <div class="movie__content">
                <h2>
                    Joker
                    <span>(2019)</span>
                </h2>
                Le résumé lorem ipsum
            </div>
        </article>
        <!-- fin film -->
    </div>
    <!-- fin bloc query_posts 4 -->

    <!-- bloc query_posts 5 -->
    <h2>tous les articles <span>en ordre alphabétique</span></h2>
    <div class="movies">
        <!-- film -->
        <article class="movie">
            <div class="movie__media">
                <img src="assets/affiche.jpg" alt="Affiche du film Joker">
            </div>
            <div class="movie__content">
                <h2>
                    Joker
                    <span>(2019)</span>
                </h2>
                Le résumé lorem ipsum
            </div>
        </article>
        <!-- fin film -->
    </div>
    <!-- fin bloc query_posts 5 -->
</section>

<?php get_sidebar(); ?>

<?php get_footer(); ?>