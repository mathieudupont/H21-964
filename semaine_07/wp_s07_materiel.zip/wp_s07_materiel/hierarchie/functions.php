<?php

//Gestion des menus
function enregistrer_menu() {
    register_nav_menus(array(
        'menu_principal' => 'Menu principal'
    )); 

}

  add_action('init', 'enregistrer_menu');
