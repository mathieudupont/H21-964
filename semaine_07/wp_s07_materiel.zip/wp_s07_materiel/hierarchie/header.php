<html lang="fr">

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <title><?php bloginfo('name'); ?> <?php wp_title(); ?></title>
    <link rel="stylesheet" href="<?php bloginfo('template_url') ?>/styles/styles.css"/>
</head>

<body <?php body_class(); ?>>

    <!-- Entête -->
    <header>

        <h1>Test Hierachie</h1>

        <!-- Navigation -->
        <?php wp_nav_menu( array(
            'theme_location'  => 'menu_principal',
            'container' => 'nav'
        )); ?>
    </header>